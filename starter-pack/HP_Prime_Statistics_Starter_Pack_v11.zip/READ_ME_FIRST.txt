HP PRIME STATISTICS STARTER PACK v11 (2026-11-02)
Roger Metcalf's teaching programs for the HP Prime Virtual Calculator
https://github.com/metcalfdds/hp-prime-statistics

WHAT YOU NEED
- A Windows PC with the HP Prime Virtual Calculator (64-bit). It is a free download from hpcalc.org, which lists Hewlett-Packard as its author. The pack was tested on the Virtual Calculator 2.4.2 (build 2026-09-09), 64-bit.
- The zip, unzipped (right-click it, Extract All).

INSTALL
1. Start the Virtual Calculator once, then close it (Calculator menu, Exit). That first start makes its folder: Documents\HP Prime\Calculators\Prime.
2. Open the unzipped folder Copy these into Prime and copy everything in it into that Prime folder. The calculator must be closed while you copy: it reads its folder only when it starts.
3. Start the Virtual Calculator. Shift, then Program (the Program Catalog) lists the programs.

RUN A PROGRAM
- In the Program Catalog, tap the program, then tap Run. Or type its name in Home (the list below) and press Enter. Nothing to check or compile first: every file in this pack was checked on the Virtual Calculator before it was packed.
- If a program ever says Syntax Error, or Run does nothing (a different version of the Virtual Calculator may want to compile it again): tap it, tap Edit, tap Check, tap OK, press Esc, then tap Run. Once is enough.
- CentralLimit is an app, built on Statistics 1Var: press Apps, highlight it and tap Start (touching its icon opens its spreadsheet instead). Then press View for its menu.
- BurrLab, ErrorRate, GaltonBoard, NormExplorer and StudRange carry MicroPython. They work the same way: the Virtual Calculator has the calculator's own MicroPython.

YOUR OWN DATA: DATALOAD
- Typing a long data set into a calculator is not feasible. The HP Prime Data Loader, a web page in this repository (its folder data-loader), turns columns pasted from Excel, SPSS or a CSV file into the calculator's own matrix file, M1.hpmat. Copy it into the Prime folder the same way (calculator closed), then run DataLoad: it puts each column, or each group's scores, into the Statistics 1Var lists D1-D9 (or Statistics 2Var C1-C9) that the other programs read.
- Open the Statistics 1Var app once (Apps) before the first load: its lists do not exist until then.
- If DataLoad says lists after the new ones hold data from before, choose clear. AnovaLab, RankLab and AgreeLab read every list that holds data as one more group (or rater).
- Sample data (optional) holds M1.hpmat: the Rossi re-arrest data (432 rows x 5 columns: week of first re-arrest, arrest 1/0, financial aid 1/0, age, prior convictions). Copy it too if you want data to try: it becomes the calculator's matrix M1 and replaces what M1 held. Then DataLoad, Scores by group, scores in column 1, groups in column 3, puts the weeks without and with financial aid in D1 and D2, ready for TTestLab.

GOOD TO KNOW
- Windows asks before it replaces a file of the same name. Replacing it replaces that program on the calculator.
- On a real HP Prime (G1 or G2), send programs with the Connectivity Kit instead, a few at a time: copying files works only for the Virtual Calculator.
- Each program's source, its change notes and how it was tested are in the repository: programs/, docs/changes/ and verify/.

WHAT IS IN THE PACK

  Program       Version     In Home, type
  AgreeLab      beta 1d     AgreeLab
  AnovaLab      beta 1b     AnovaLab
  BayesTree     beta 8g     BayesTree
  BiNorm3D      beta 1c     BiNorm3D
  BurrLab       beta 1l     BurrLab  (MicroPython)
  CICatcher     beta 2f     CICatcher
  CentralLimit  beta 3e     Apps > CentralLimit
  ChiTable      beta 3h     ChiTable
  DNAMixLR      beta 3g     DNAMixLR
  DataLoad      beta 1c     DATALOAD
  EpiStats      v1.7g       EpiStats
  ErrorRate     beta 1f     ErrorRate  (MicroPython)
  FitCheck      beta 1b     FitCheck
  GaltonBoard   beta 3g     GaltonBoard  (MicroPython)
  Norm3         v2.4e       Norm3
  NormExplorer  beta 42g    NormExp  (MicroPython)
  PowerViz      v2.5n       POWERVIZ
  RankLab       beta 1c     RankLab
  ResampLab     beta 1d     ResampLab
  RiskLab       beta 1d     RiskLab
  SampDist      v2.3g       SampDist
  ScatterLab    beta 2g     ScatterLab
  SeizureLab    beta 1c     SeizureLab
  StatDist      v2.7i       StatDist
  StudRange     beta 15i    StudRange  (MicroPython)
  SurvLab       beta 1c     SurvLab
  TTestLabG     beta 1b     TTESTLABG
  TTestLab      beta 1d     TTESTLAB
  TestChooser   beta 2d     TestChooser
  TrendTest     beta 3i     TrendTest

Free for educational and personal use. (C) 2026 Roger Metcalf.